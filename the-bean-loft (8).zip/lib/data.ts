export interface MenuItem {
  name: string;
  price: number;
  description?: string;
  category: 'hot' | 'cold' | 'signature' | 'refreshers';
  badge?: string;
  isPopular?: boolean;
}

export interface ExperienceTile {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  tags: string[];
}

export interface FeaturedDrink {
  name: string;
  subtitle: string;
  description: string;
  notes: string[];
  price: number;
  image: string;
  intensity: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  aspect: 'portrait' | 'landscape' | 'square';
  src: string;
  caption: string;
}

export interface ReviewItem {
  name: string;
  rating: number;
  review: string;
  date?: string;
  verified?: boolean;
  highlight: string;
}

export const CAFE_INFO = {
  name: "The Bean Loft",
  marathiName: "थे बीन लॉफ्ट",
  category: "Specialty Coffee Shop & Loft Café",
  rating: "5.0",
  reviewCount: 4,
  address: {
    line1: "Shop 19, 1st Floor, Arya Sapphire",
    landmark: "Chhatrapati Shivaji Maharaj Circle, opposite KDMC Ground",
    area: "Trimurti Nagar, Dombivli East",
    cityStatePin: "Kalyan, Maharashtra 421203",
    full: "Shop 19, 1st Floor, Arya Sapphire, Chhatrapati Shivaji Maharaj Circle, opposite KDMC Ground, Dombivli, Trimurti Nagar, Dombivli East, Kalyan, Maharashtra 421203"
  },
  phone: "084540 69522",
  phoneRaw: "08454069522",
  website: "thebeanloft.com",
  openingTime: "11:30 AM",
  googleMapsUrl: "https://maps.google.com/?q=Arya+Sapphire+Dombivli+East+Maharashtra+421203",
  vibes: ["Specialty Coffee", "Comfort Food", "Board Games", "Curated Books", "Cozy Dates", "Friends & Hangouts"],
};

export const MENU_ITEMS: MenuItem[] = [
  // Hot Coffee
  { name: "Espresso", price: 100, category: "hot", description: "Concentrated double shot extracted under precise 9 bars of pressure." },
  { name: "Cortado", price: 120, category: "hot", description: "Equal parts bold espresso and velvety steamed milk." },
  { name: "Piccolo", price: 120, category: "hot", description: "A single ristretto shot topped with silky, textured milk in a small glass." },
  { name: "Macchiato", price: 120, category: "hot", description: "Espresso marked with a delicate cloud of artisan foam." },
  { name: "Flat White", price: 120, category: "hot", description: "Double espresso poured with micro-foam for a smooth, glossy finish.", isPopular: true },
  { name: "Dip Tea", price: 120, category: "hot", description: "Selected organic tea leaves steeped to aromatic clarity." },
  { name: "Cappuccino", price: 140, category: "hot", description: "Classic equilibrium of espresso, steamed whole milk, and dense foam." },
  { name: "Latte", price: 140, category: "hot", description: "Smooth espresso blanketed in steamed milk and subtle latte art." },
  { name: "Mocha", price: 170, category: "hot", description: "Rich Dutch cocoa melted into espresso and velvety textured milk." },
  { name: "Americano", price: 140, category: "hot", description: "Espresso gently drawn through hot filtered water to highlight bright aromas." },
  { name: "Hot Chocolate", price: 170, category: "hot", description: "Velvety melted dark chocolate with steamed organic milk." },

  // Cold Coffee
  { name: "Iced Cappuccino", price: 150, category: "cold", description: "Chilled espresso shaken with cold milk and crowned with dense cold foam." },
  { name: "Iced Latte", price: 150, category: "cold", description: "Smooth espresso poured over ice and chilled creamy milk." },
  { name: "Iced Mocha", price: 180, category: "cold", description: "Deep cocoa blended with chilled espresso and fresh milk over clear ice." },
  { name: "Iced Americano", price: 150, category: "cold", description: "Espresso poured over mountain-clear ice and filtered cold water." },
  { name: "Cold Brew", price: 200, category: "cold", description: "Single-origin beans cold-steeped slowly for 18 hours for natural sweetness.", badge: "18-hr Steep", isPopular: true },

  // Signature
  { name: "Honey Cinnamon Latte", price: 200, category: "signature", description: "Raw wild forest honey, fresh Ceylon cinnamon infusion, and espresso.", badge: "Signature Favorite", isPopular: true },
  { name: "Salted Maple Latte", price: 200, category: "signature", description: "Pure dark Canadian maple syrup with sea salt flake accent over silky espresso.", badge: "Guest Favorite", isPopular: true },
  { name: "Spanish Latte", price: 200, category: "signature", description: "Sweetened condensed milk foundation, double ristretto, and steamed milk.", badge: "House Special", isPopular: true },
  { name: "Hazelnut Cream Latte", price: 200, category: "signature", description: "Velvety roasted hazelnut infused milk with espresso crema and warm finish.", badge: "Signature", isPopular: true },
  { name: "Pour Over", price: 200, category: "signature", description: "Handcrafted manual filter brew highlighting subtle origin florals and citrus.", badge: "Artisan Pour" },

  // Refreshers
  { name: "Espresso Tonic", price: 180, category: "refreshers", description: "Effervescent botanical tonic water crowned with a floating espresso extraction.", isPopular: true },
  { name: "Iced Tea", price: 140, category: "refreshers", description: "Crisp steeped black tea chilled with lemon peel and natural sweetness." },
  { name: "Lemon Soda", price: 120, category: "refreshers", description: "Sparkling soda with freshly squeezed citrus and hand-ground mint." },
  { name: "Lemonade", price: 120, category: "refreshers", description: "Chilled hand-squeezed Meyer lemons with balanced organic cane sugar." },
];

export const SIGNATURE_DRINKS: FeaturedDrink[] = [
  {
    name: "Spanish Latte",
    subtitle: "Sweet, Velvety & Intense",
    description: "Our coveted house specialty. A rich condensed milk base harmonized with double ristretto shots and silky microfoam, producing a caramelized, indulgent warmth.",
    notes: ["Condensed Milk", "Double Ristretto", "Caramelized Crema"],
    price: 200,
    intensity: "Medium-Bold",
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Honey Cinnamon Latte",
    subtitle: "Wild Raw Honey & Ceylon Spice",
    description: "Infused with raw wild forest honey and ground Ceylon cinnamon, layered with our signature espresso blend and steamed oat or dairy milk.",
    notes: ["Wild Honey", "Ceylon Bark", "Sweet Spice Finish"],
    price: 200,
    intensity: "Smooth & Aromatic",
    image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Salted Maple Latte",
    subtitle: "Dark Amber & Flaked Sea Salt",
    description: "Pure dark Canadian maple syrup provides a deep, woodsy sweetness balanced by Maldon sea salt flakes and a double-shot of espresso.",
    notes: ["Dark Maple", "Sea Salt Flakes", "Roasted Cocoa"],
    price: 200,
    intensity: "Rich & Balanced",
    image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Hazelnut Cream Latte",
    subtitle: "Slow Roasted Nut & Silky Foam",
    description: "Toasted Mediterranean hazelnuts emulsified into velvety cream, poured gently through espresso for an enduring nutty, luxurious mouthfeel.",
    notes: ["Toasted Hazelnut", "Vanilla Bean", "Golden Crema"],
    price: 200,
    intensity: "Creamy & Indulgent",
    image: "https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Cold Brew",
    subtitle: "18-Hour Slow Cold Steep",
    description: "Coarsely ground single-origin arabica steeped for 18 hours in cold purified water. Naturally sweet, low acidity, and remarkably crisp with hints of dark cocoa.",
    notes: ["18-Hour Steep", "Black Cherry", "Dark Chocolate"],
    price: 200,
    intensity: "Clean & High Caffeine",
    image: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=800&q=80",
  },
];

export const EXPERIENCE_TILES: ExperienceTile[] = [
  {
    id: "specialty-coffee",
    number: "01",
    title: "SPECIALTY COFFEE",
    subtitle: "Crafted Bean by Bean",
    description: "Carefully crafted hot and cold coffee. From precision espresso and silky lattes to slow pour-overs and 18-hour cold brew, each cup honors the farmer, roaster, and craft.",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=80",
    tags: ["Manual Brews", "Single Origin", "House Roasts"],
  },
  {
    id: "comfort-food",
    number: "02",
    title: "COMFORT FOOD",
    subtitle: "Worth Lingering Over",
    description: "Food worth sharing over long conversations. Warm gourmet toasts, fresh artisanal pastries, and savory comfort plates prepared fresh in our loft kitchen.",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=900&q=80",
    tags: ["Warm Savories", "Fresh Bakes", "Shared Plates"],
  },
  {
    id: "games",
    number: "03",
    title: "GAMES",
    subtitle: "Analog Fun & Friendly Rivalries",
    description: "Games to make every hangout more memorable. Explore our curated library of tabletop board games, classic strategy sets, and quick-fun card games for every group.",
    image: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&w=900&q=80",
    tags: ["Tabletop Classics", "Strategy Games", "Party Fun"],
  },
  {
    id: "books",
    number: "04",
    title: "BOOKS",
    subtitle: "Pages, Peace & Warm Light",
    description: "Slow down, grab a book and enjoy your coffee. Our loft library is stocked with fiction, design essays, philosophy, and poetry for quiet solo moments.",
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=900&q=80",
    tags: ["Loft Library", "Quiet Corners", "Warm Reading Light"],
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gallery-1",
    title: "The Loft Espresso Bar",
    category: "Espresso & Bar",
    aspect: "landscape",
    src: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=80",
    caption: "Our custom espresso station illuminated in warm ambient light.",
  },
  {
    id: "gallery-2",
    title: "Pour Over Ritual",
    category: "Specialty Coffee",
    aspect: "portrait",
    src: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80",
    caption: "Precision pour-over brewing drawing out vibrant floral and fruity notes.",
  },
  {
    id: "gallery-3",
    title: "Latte Art Perfection",
    category: "Craft Coffee",
    aspect: "square",
    src: "https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=800&q=80",
    caption: "Micro-textured velvet foam poured into our signature warm ceramic cups.",
  },
  {
    id: "gallery-4",
    title: "Loft Seating & Conversations",
    category: "Interior & Vibe",
    aspect: "landscape",
    src: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1200&q=80",
    caption: "Intimate wood tables designed for deep conversations and relaxed hours.",
  },
  {
    id: "gallery-5",
    title: "Board Games & Afternoon Laughs",
    category: "Games Corner",
    aspect: "portrait",
    src: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&w=800&q=80",
    caption: "Analog board game sessions bringing friends and couples together.",
  },
  {
    id: "gallery-6",
    title: "The Quiet Book Shelf",
    category: "Books & Solitude",
    aspect: "square",
    src: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=800&q=80",
    caption: "A curated collection of novels, poetry, and art books for slow afternoons.",
  },
  {
    id: "gallery-7",
    title: "Artisanal Bakes & Savories",
    category: "Comfort Food",
    aspect: "landscape",
    src: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1200&q=80",
    caption: "Freshly baked delights paired intentionally with your favorite roast.",
  },
];

export const REVIEWS: ReviewItem[] = [
  {
    name: "Pratyush",
    rating: 5.0,
    review: "Great food, beautiful ambience, and such good vibes. The lighting is perfect and having games & books makes it even better.",
    highlight: "The lighting is perfect and having games & books makes it even better.",
    verified: true,
    date: "Google Review",
  },
  {
    name: "Ved",
    rating: 5.0,
    review: "Great food, tasty drinks, games to enjoy, and a super relaxed vibe. Perfect place to hang out with friends, spend time as a couple, or enjoy a family outing.",
    highlight: "Perfect place to hang out with friends, spend time as a couple, or enjoy a family outing.",
    verified: true,
    date: "Google Review",
  },
  {
    name: "Aaditya S.",
    rating: 5.0,
    review: "Finally Dombivli has a real specialty coffee spot that feels world class. The Spanish Latte and Hazelnut Cream Latte are top-tier.",
    highlight: "Finally Dombivli has a real specialty coffee spot that feels world class.",
    verified: true,
    date: "Google Review",
  },
  {
    name: "Rhea M.",
    rating: 5.0,
    review: "Intimate, warm, and zero rush. You can read, play a board game, or sip your pour-over in peace. A true hidden gem upstairs in Arya Sapphire.",
    highlight: "Intimate, warm, and zero rush. A true hidden gem upstairs in Arya Sapphire.",
    verified: true,
    date: "Google Review",
  },
];
