'use client';

import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Navigation, Compass, ExternalLink } from 'lucide-react';
import { CAFE_INFO } from '@/lib/data';

export function VisitSection() {
  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  return (
    <section
      id="visit"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#0E0B09] border-t border-[rgba(245,239,230,0.08)] overflow-hidden"
      aria-label="Visit The Bean Loft"
    >
      {/* Ambient background glow */}
      <div
        className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full pointer-events-none opacity-15"
        style={{
          background: 'radial-gradient(circle, rgba(196,122,74,0.2) 0%, rgba(14,11,9,0) 70%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="max-w-3xl mb-14 sm:mb-20">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C47A4A]" />
            <span className="text-xs font-sans-loft uppercase tracking-[0.24em] text-[#D19A66] font-medium">
              VISIT THE LOFT
            </span>
          </div>

          <h2 className="font-serif-loft text-4xl sm:text-6xl lg:text-7xl text-[#F5EFE6] leading-[1.05] font-light mb-4">
            Your table upstairs <br />
            <span className="italic text-[#C47A4A] font-normal">is waiting.</span>
          </h2>

          <p className="font-sans-loft text-base sm:text-lg text-[#E7DAC8]/85 font-light">
            Specialty coffee, comforting food, games, and books right in the heart of Dombivli.
          </p>
        </div>

        {/* 2 Column Grid: Details & Map Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
          {/* Column 1: Details & Immediate Action Buttons */}
          <motion.div
            initial={{ opacity: 0, x: -25 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8, ease: easeLuxury }}
            className="lg:col-span-5 flex flex-col justify-between bg-[#1B1511] border border-[rgba(245,239,230,0.12)] p-8 sm:p-10 rounded-2xl shadow-xl"
          >
            <div className="space-y-8">
              {/* Address Block */}
              <div>
                <div className="flex items-center gap-2 text-xs font-sans-loft uppercase tracking-[0.2em] text-[#D19A66] mb-3 font-medium">
                  <MapPin className="w-4 h-4 text-[#C47A4A]" />
                  <span>ADDRESS & ARRIVAL</span>
                </div>
                <div className="font-serif-loft text-2xl sm:text-3xl text-[#F5EFE6] leading-snug mb-2">
                  Shop 19, 1st Floor, Arya Sapphire
                </div>
                <p className="font-sans-loft text-sm text-[#A99B8E] leading-relaxed">
                  Chhatrapati Shivaji Maharaj Circle, opposite KDMC Ground,
                  Trimurti Nagar, Dombivli East, Kalyan, Maharashtra 421203
                </p>
                <div className="mt-3 inline-flex items-center gap-2 text-xs text-[#E7DAC8] bg-[#241B16] px-3 py-1.5 rounded-lg border border-[rgba(245,239,230,0.08)]">
                  <Compass className="w-3.5 h-3.5 text-[#7E8465]" />
                  <span>5 mins from Dombivli Railway Station (East)</span>
                </div>
              </div>

              {/* Hours Block */}
              <div className="border-t border-[rgba(245,239,230,0.08)] pt-6">
                <div className="flex items-center gap-2 text-xs font-sans-loft uppercase tracking-[0.2em] text-[#D19A66] mb-2 font-medium">
                  <Clock className="w-4 h-4 text-[#7E8465]" />
                  <span>HOURS</span>
                </div>
                <div className="font-serif-loft text-3xl text-[#F5EFE6] leading-none mb-1">
                  11:30 AM – Late
                </div>
                <p className="font-sans-loft text-xs text-[#A99B8E] mt-1 font-light">
                  Open seven days a week for slow afternoons and quiet evening reading.
                </p>
              </div>

              {/* Phone Block */}
              <div className="border-t border-[rgba(245,239,230,0.08)] pt-6">
                <div className="flex items-center gap-2 text-xs font-sans-loft uppercase tracking-[0.2em] text-[#D19A66] mb-2 font-medium">
                  <Phone className="w-4 h-4 text-[#D19A66]" />
                  <span>PHONE & RESERVATIONS</span>
                </div>
                <a
                  href={`tel:${CAFE_INFO.phoneRaw}`}
                  className="font-serif-loft text-2xl text-[#F5EFE6] hover:text-[#D19A66] transition-colors"
                >
                  {CAFE_INFO.phone}
                </a>
              </div>
            </div>

            {/* Immediate Action Buttons */}
            <div className="pt-8 mt-8 border-t border-[rgba(245,239,230,0.08)] flex flex-col sm:flex-row gap-3.5">
              <a
                href={CAFE_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="visit-directions-btn"
                className="flex-1 py-3.5 px-6 rounded-full bg-[#F5EFE6] text-[#0E0B09] font-sans-loft text-xs uppercase tracking-[0.16em] font-medium flex items-center justify-center gap-2 hover:bg-[#E7DAC8] hover:-translate-y-0.5 transition-all shadow-md"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Directions</span>
              </a>

              <a
                href={`tel:${CAFE_INFO.phoneRaw}`}
                id="visit-call-btn"
                className="flex-1 py-3.5 px-6 rounded-full bg-transparent border border-[rgba(245,239,230,0.25)] text-[#F5EFE6] font-sans-loft text-xs uppercase tracking-[0.16em] font-medium flex items-center justify-center gap-2 hover:border-[#F5EFE6] hover:bg-[#F5EFE6]/08 hover:-translate-y-0.5 transition-all"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Café</span>
              </a>
            </div>
          </motion.div>

          {/* Column 2: Styled Architectural Location View Card */}
          <motion.div
            initial={{ opacity: 0, x: 25 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8, delay: 0.15, ease: easeLuxury }}
            className="lg:col-span-7 relative rounded-2xl overflow-hidden border border-[rgba(245,239,230,0.12)] min-h-[420px] bg-[#1B1511] flex flex-col justify-between p-8 sm:p-10 shadow-xl"
          >
            {/* Background Texture & Map Frame */}
            <div className="absolute inset-0 -z-10">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.538167389146!2d73.0886617!3d19.2153835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7950b7b1322ab%3A0x6b633ec7c9a444dd!2sArya%20Sapphire%2C%20Trimurti%20Nagar%2C%20Dombivli%20East%2C%20Maharashtra%20421203!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) brightness(85%) contrast(110%)' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full opacity-40 hover:opacity-70 transition-opacity duration-500 pointer-events-auto"
                title="The Bean Loft Map Location"
              />
            </div>

            {/* Floating Info Overlay Card */}
            <div className="relative z-10 max-w-sm p-6 rounded-xl bg-[#0E0B09]/90 backdrop-blur-md border border-[rgba(245,239,230,0.15)] shadow-2xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2 h-2 rounded-full bg-[#7E8465] animate-ping" />
                <span className="text-[11px] font-sans-loft tracking-widest uppercase text-[#D19A66] font-medium">
                  LANDMARK LOCATION
                </span>
              </div>
              <h3 className="font-serif-loft text-2xl text-[#F5EFE6] mb-2">
                Arya Sapphire, 1st Floor
              </h3>
              <p className="font-sans-loft text-xs text-[#E7DAC8]/80 leading-relaxed font-light">
                Directly above Chhatrapati Shivaji Maharaj Circle, opposite KDMC Ground. Take the stairs or elevator to the 1st floor.
              </p>

              <div className="mt-4 pt-3 border-t border-[rgba(245,239,230,0.1)] flex items-center justify-between">
                <span className="text-[11px] font-sans-loft text-[#A99B8E]">Dombivli East</span>
                <a
                  href={CAFE_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-sans-loft text-[#C47A4A] hover:underline inline-flex items-center gap-1"
                >
                  Open in Maps
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Bottom Tag */}
            <div className="relative z-10 self-end">
              <div className="px-4 py-2 rounded-full bg-[#0E0B09]/80 backdrop-blur-md border border-[rgba(245,239,230,0.15)] text-xs font-sans-loft text-[#E7DAC8]">
                Easy parking near KDMC ground
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default VisitSection;
