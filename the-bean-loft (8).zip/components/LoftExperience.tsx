'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion } from 'motion/react';
import { Sparkles, Heart, Users, Gamepad2, Book, Coffee } from 'lucide-react';

export function LoftExperience() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { clientX, clientY, currentTarget } = e;
    const { left, top, width, height } = currentTarget.getBoundingClientRect();
    const x = (clientX - left) / width - 0.5;
    const y = (clientY - top) / height - 0.5;
    setMousePos({ x, y });
  };

  const handleMouseLeave = () => {
    setMousePos({ x: 0, y: 0 });
  };

  const floatingLabels = [
    { text: 'COFFEE', xRatio: 0.12, yRatio: 0.25, depth: 15, delay: 0.1, icon: Coffee },
    { text: 'GAMES', xRatio: 0.78, yRatio: 0.22, depth: -18, delay: 0.2, icon: Gamepad2 },
    { text: 'BOOKS', xRatio: 0.22, yRatio: 0.75, depth: 22, delay: 0.3, icon: Book },
    { text: 'CONVERSATIONS', xRatio: 0.72, yRatio: 0.78, depth: -20, delay: 0.4, icon: Sparkles },
    { text: 'DATE NIGHT', xRatio: 0.5, yRatio: 0.18, depth: 12, delay: 0.5, icon: Heart },
    { text: 'FRIENDS', xRatio: 0.82, yRatio: 0.48, depth: -14, delay: 0.6, icon: Users },
    { text: 'FAMILY', xRatio: 0.14, yRatio: 0.52, depth: 16, delay: 0.7, icon: Users },
  ];

  return (
    <section
      id="atmosphere"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative w-full min-h-[700px] lg:min-h-[800px] flex items-center justify-center overflow-hidden py-24 sm:py-32 bg-[#0E0B09]"
      aria-label="The Loft Atmosphere"
    >
      {/* Background Full Width Image */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <motion.div
          animate={{
            x: mousePos.x * -20,
            y: mousePos.y * -20,
          }}
          transition={{ ease: 'easeOut', duration: 0.6 }}
          className="relative w-[105%] h-[105%] -left-[2.5%] -top-[2.5%]"
        >
          <Image
            src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=2200&q=85"
            alt="The Bean Loft interior atmosphere"
            fill
            sizes="100vw"
            referrerPolicy="no-referrer"
            className="object-cover object-center filter brightness-[0.55] contrast-[1.08]"
          />
        </motion.div>

        {/* Cinematic Vignette Overlay */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at center, rgba(14,11,9,0.4) 0%, rgba(14,11,9,0.85) 75%, #0E0B09 100%)',
          }}
        />

        {/* Film grain */}
        <div className="absolute inset-0 grain-overlay opacity-80" />
      </div>

      {/* Floating Parallax Labels on Desktop */}
      <div className="hidden md:block absolute inset-0 pointer-events-none z-10">
        {floatingLabels.map((item, idx) => {
          const Icon = item.icon;
          return (
            <motion.div
              key={item.text}
              animate={{
                x: mousePos.x * item.depth,
                y: mousePos.y * item.depth,
              }}
              transition={{ ease: 'easeOut', duration: 0.7 }}
              style={{
                left: `${item.xRatio * 100}%`,
                top: `${item.yRatio * 100}%`,
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-auto"
            >
              <div className="group px-4 py-2 rounded-full border border-[rgba(245,239,230,0.18)] bg-[#1B1511]/85 backdrop-blur-md text-[#E7DAC8] hover:text-[#F5EFE6] hover:border-[#D19A66] hover:bg-[#C47A4A]/30 transition-all duration-300 shadow-xl cursor-default flex items-center gap-2">
                <Icon className="w-3.5 h-3.5 text-[#D19A66]" />
                <span className="text-[11px] font-sans-loft tracking-[0.24em] font-medium uppercase">
                  {item.text}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Center Cinematic Editorial Focus */}
      <div className="relative z-20 max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#D19A66]/30 bg-[#1B1511]/90 backdrop-blur-xs mb-6"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#7E8465]" />
          <span className="text-[11px] font-sans-loft tracking-[0.24em] uppercase text-[#E7DAC8]">
            AN OASIS IN DOMBIVLI
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 0.15 }}
          className="font-serif-loft text-4xl sm:text-6xl md:text-7xl lg:text-8xl text-[#F5EFE6] font-light leading-[1.04] tracking-tight mb-6"
        >
          Come for the coffee. <br />
          <span className="italic text-[#D19A66] font-normal">Stay for the vibe.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="max-w-xl mx-auto font-sans-loft text-sm sm:text-base text-[#E7DAC8]/85 font-light leading-relaxed mb-8"
        >
          Soft acoustic melodies, warm timber tables, curated paperbacks, board games to challenge your companions, and zero hurry to finish.
        </motion.p>

        {/* Mobile Friendly Tags display */}
        <div className="md:hidden flex flex-wrap justify-center gap-2 pt-2">
          {floatingLabels.map((item) => (
            <span
              key={item.text}
              className="text-[10px] font-sans-loft uppercase tracking-widest text-[#E7DAC8] bg-[#1B1511]/80 px-3 py-1.5 rounded-full border border-[rgba(245,239,230,0.12)]"
            >
              {item.text}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
