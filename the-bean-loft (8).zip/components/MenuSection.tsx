'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Flame, Coffee, Sparkles, CupSoda, X, Info } from 'lucide-react';
import { MENU_ITEMS, MenuItem } from '@/lib/data';

export function MenuSection() {
  const [activeTab, setActiveTab] = useState<'hot' | 'cold' | 'signature' | 'refreshers'>('hot');
  const [selectedItemDetail, setSelectedItemDetail] = useState<MenuItem | null>(null);

  const categories = [
    { id: 'hot', label: 'Hot Coffee', icon: Flame },
    { id: 'cold', label: 'Cold Coffee', icon: Coffee },
    { id: 'signature', label: 'Signature', icon: Sparkles },
    { id: 'refreshers', label: 'Refreshers', icon: CupSoda },
  ] as const;

  const filteredItems = MENU_ITEMS.filter((item) => item.category === activeTab);

  return (
    <section
      id="menu"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#0E0B09] overflow-hidden"
      aria-label="The Bean Loft Coffee Menu"
    >
      {/* Background ambient glow */}
      <div
        className="absolute top-1/4 right-0 w-[500px] h-[500px] rounded-full pointer-events-none opacity-15"
        style={{
          background: 'radial-gradient(circle, rgba(209,154,102,0.2) 0%, rgba(14,11,9,0) 70%)',
        }}
      />

      <div className="max-w-4xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#D19A66]/30 bg-[#1B1511]/80 backdrop-blur-xs mb-3.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C47A4A]" />
            <span className="text-[11px] font-sans-loft tracking-[0.22em] uppercase text-[#E7DAC8]">
              FROM THE BAR
            </span>
          </div>

          <h2 className="font-serif-loft text-4xl sm:text-5xl lg:text-6xl text-[#F5EFE6] leading-[1.08] font-light">
            Coffee, exactly <br />
            <span className="italic text-[#C47A4A] font-normal">how you like it.</span>
          </h2>
          <p className="font-sans-loft text-sm sm:text-base text-[#A99B8E] mt-4 font-light">
            Every cup is dialed in with single-origin beans and freshly pulled shots by our baristas on the 1st floor.
          </p>
        </div>

        {/* Elegant Category Tabs with Animated Indicator */}
        <div className="flex justify-center mb-12 sm:mb-16">
          <div
            role="tablist"
            className="inline-flex flex-wrap items-center justify-center p-1.5 rounded-full bg-[#1B1511] border border-[rgba(245,239,230,0.12)] gap-1 shadow-inner"
          >
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeTab === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  id={`menu-tab-${cat.id}`}
                  onClick={() => setActiveTab(cat.id)}
                  className={`relative px-5 sm:px-7 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-sans-loft tracking-[0.14em] uppercase transition-colors duration-300 flex items-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D19A66] ${
                    isActive ? 'text-[#0E0B09] font-medium' : 'text-[#E7DAC8]/70 hover:text-[#F5EFE6]'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeMenuSpreadTab"
                      className="absolute inset-0 bg-[#F5EFE6] rounded-full shadow-md"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    />
                  )}
                  <Icon className={`w-3.5 h-3.5 relative z-10 ${isActive ? 'text-[#0E0B09]' : 'text-[#D19A66]'}`} />
                  <span className="relative z-10">{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Rows: Editorial Spread Layout with Thin Rules and Generous Spacing */}
        <div className="relative min-h-[380px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="divide-y divide-[rgba(245,239,230,0.08)] border-y border-[rgba(245,239,230,0.1)]"
            >
              {filteredItems.map((item) => (
                <div
                  key={item.name}
                  onClick={() => setSelectedItemDetail(item)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelectedItemDetail(item);
                    }
                  }}
                  tabIndex={0}
                  role="button"
                  aria-label={`${item.name}, ₹${item.price}. Click to view details.`}
                  className="group py-5 sm:py-6 px-4 -mx-4 rounded-xl flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 hover:bg-[#1B1511]/60 transition-all duration-300 cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D19A66]"
                >
                  {/* Left Column: Title, Badges, and Description */}
                  <div className="flex-1 pr-4">
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-serif-loft text-2xl sm:text-3xl text-[#F5EFE6] group-hover:text-[#D19A66] transition-colors">
                        {item.name}
                      </span>

                      {item.badge && (
                        <span className="text-[9px] uppercase tracking-widest font-sans-loft px-2.5 py-0.5 rounded-full bg-[#C47A4A]/20 text-[#D19A66] border border-[#C47A4A]/30">
                          {item.badge}
                        </span>
                      )}

                      {item.isPopular && !item.badge && (
                        <span className="text-[9px] uppercase tracking-widest font-sans-loft px-2 py-0.5 rounded-full bg-[#7E8465]/20 text-[#A99B8E] border border-[#7E8465]/30">
                          Popular
                        </span>
                      )}
                    </div>

                    {item.description && (
                      <p className="font-sans-loft text-xs sm:text-sm text-[#A99B8E] font-light leading-relaxed max-w-xl">
                        {item.description}
                      </p>
                    )}
                  </div>

                  {/* Right Column: Beautifully Aligned Price with No Layout Jumps */}
                  <div className="shrink-0 flex items-center gap-2 self-start sm:self-baseline">
                    <span className="font-sans-loft text-xs text-[#D19A66]">₹</span>
                    <span className="font-serif-loft text-2xl sm:text-3xl text-[#F5EFE6] tabular-nums tracking-tight">
                      {item.price}
                    </span>
                  </div>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Small Bottom Editorial Note */}
        <div className="mt-8 text-center text-xs font-sans-loft text-[#A99B8E]/70">
          Oat milk, almond milk, extra espresso shots and sugar-free syrups available upon request at the bar.
        </div>
      </div>

      {/* Item Detail Modal */}
      <AnimatePresence>
        {selectedItemDetail && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-md rounded-2xl bg-[#1B1511] border border-[rgba(245,239,230,0.15)] p-6 sm:p-8 shadow-2xl"
              role="dialog"
              aria-modal="true"
              aria-labelledby="menu-detail-title"
            >
              <button
                type="button"
                onClick={() => setSelectedItemDetail(null)}
                aria-label="Close modal"
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#0E0B09] border border-[rgba(245,239,230,0.1)] flex items-center justify-center text-[#E7DAC8] hover:text-[#F5EFE6] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="text-[10px] tracking-[0.24em] font-sans-loft text-[#D19A66] uppercase mb-1 font-medium">
                {selectedItemDetail.category} Coffee
              </div>

              <h3 id="menu-detail-title" className="font-serif-loft text-3xl text-[#F5EFE6] mb-2">
                {selectedItemDetail.name}
              </h3>

              <div className="text-xl font-serif-loft text-[#C47A4A] mb-4">
                ₹{selectedItemDetail.price}
              </div>

              <p className="font-sans-loft text-sm text-[#E7DAC8]/85 leading-relaxed mb-6 font-light">
                {selectedItemDetail.description || 'Crafted fresh upon order by our baristas on the 1st floor.'}
              </p>

              <div className="pt-4 border-t border-[rgba(245,239,230,0.1)] flex items-center justify-between text-xs font-sans-loft text-[#A99B8E]">
                <span>1st Floor, Arya Sapphire</span>
                <span className="text-[#D19A66]">The Bean Loft</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

export default MenuSection;
