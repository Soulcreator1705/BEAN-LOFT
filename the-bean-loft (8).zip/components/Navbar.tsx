'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, Menu as MenuIcon, X, Phone, MapPin, Clock } from 'lucide-react';
import { CAFE_INFO } from '@/lib/data';

interface NavbarProps {
  onOpenQuickFind?: () => void;
}

export function Navbar({ onOpenQuickFind }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 70);

      const sections = ['home', 'story', 'experience', 'menu', 'featured', 'gallery', 'reviews', 'visit'];
      const scrollPosition = window.scrollY + 140;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'Our Story', href: '#story', id: 'story' },
    { label: 'Menu', href: '#menu', id: 'menu' },
    { label: 'Experience', href: '#experience', id: 'experience' },
    { label: 'Gallery', href: '#gallery', id: 'gallery' },
    { label: 'Reviews', href: '#reviews', id: 'reviews' },
    { label: 'Visit', href: '#visit', id: 'visit' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        id="main-navigation-bar"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[rgba(14,11,9,0.82)] backdrop-blur-[16px] border-b border-[rgba(245,239,230,0.10)] py-3.5 shadow-lg shadow-black/30'
            : 'bg-transparent py-5 lg:py-6 border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 flex items-center justify-between">
          {/* Logo & Marathi Subtitle */}
          <Link
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="group flex flex-col items-start focus:outline-none"
            id="nav-logo-link"
          >
            <div className="flex items-center gap-2">
              <span className="font-serif-loft text-xl sm:text-2xl tracking-[0.14em] uppercase text-[#F5EFE6] group-hover:text-[#D19A66] transition-colors duration-300">
                THE BEAN LOFT
              </span>
              <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-[#C47A4A]" />
            </div>
            <span className="text-[10px] tracking-[0.24em] uppercase text-[#A99B8E] font-sans-loft opacity-80 group-hover:opacity-100 transition-opacity">
              थे बीन लॉफ्ट • DOMBIVLI
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8 xl:gap-9" aria-label="Main Navigation">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  id={`nav-link-${link.id}`}
                  className={`text-xs tracking-[0.18em] uppercase font-sans-loft transition-colors duration-300 relative py-1 ${
                    isActive ? 'text-[#D19A66]' : 'text-[#E7DAC8]/80 hover:text-[#F5EFE6]'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <motion.span
                      layoutId="activeNavIndicator"
                      className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#C47A4A]"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Right Action */}
          <div className="flex items-center gap-3 sm:gap-4">
            <a
              href="#visit"
              onClick={(e) => handleNavClick(e, '#visit')}
              id="nav-find-us-cta"
              data-cursor="cta"
              className="relative group overflow-hidden px-4 sm:px-6 py-2 sm:py-2.5 rounded-full border border-[#D19A66]/60 bg-[#C47A4A]/10 hover:bg-[#C47A4A] text-[#F5EFE6] transition-all duration-300 flex items-center gap-1.5 text-xs tracking-[0.16em] uppercase font-sans-loft"
            >
              <span>Find Us</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#D19A66] group-hover:text-[#F5EFE6] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
            </a>

            {/* Mobile Hamburger Toggle */}
            <button
              type="button"
              id="mobile-menu-toggle-button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#E7DAC8] hover:text-[#F5EFE6] focus:outline-none focus:ring-1 focus:ring-[#C47A4A] rounded-md transition-colors"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Full-Screen Overlay Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-50 bg-[#0E0B09] flex flex-col justify-between p-6 sm:p-8 lg:hidden grain-overlay overflow-y-auto"
            id="mobile-menu-overlay"
          >
            {/* Top Bar inside Drawer */}
            <div className="flex items-center justify-between border-b border-[rgba(245,239,230,0.12)] pb-4">
              <div>
                <span className="font-serif-loft text-xl tracking-[0.14em] uppercase text-[#F5EFE6]">
                  THE BEAN LOFT
                </span>
                <p className="text-[10px] tracking-[0.2em] text-[#A99B8E] uppercase">थे बीन लॉफ्ट</p>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-[#E7DAC8] hover:text-[#F5EFE6] rounded-full border border-[rgba(245,239,230,0.15)]"
                aria-label="Close menu"
                id="close-mobile-menu-btn"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Mobile Links */}
            <div className="flex flex-col gap-6 py-8">
              {navLinks.map((link, idx) => (
                <motion.a
                  key={link.id}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * idx, duration: 0.3 }}
                  className="group flex items-baseline justify-between border-b border-[rgba(245,239,230,0.06)] pb-3"
                  id={`mobile-nav-${link.id}`}
                >
                  <span className="font-serif-loft text-2xl sm:text-3xl tracking-wide text-[#F5EFE6] group-hover:text-[#D19A66] transition-colors">
                    {link.label}
                  </span>
                  <span className="text-[11px] font-sans-loft tracking-widest text-[#A99B8E]">
                    0{idx + 1}
                  </span>
                </motion.a>
              ))}
            </div>

            {/* Mobile Footer Info */}
            <div className="border-t border-[rgba(245,239,230,0.12)] pt-6 flex flex-col gap-4 text-xs font-sans-loft text-[#A99B8E]">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C47A4A] shrink-0 mt-0.5" />
                <span>Shop 19, 1st Floor, Arya Sapphire, Dombivli East</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#7E8465] shrink-0" />
                <span>Opens daily at {CAFE_INFO.openingTime}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#D19A66] shrink-0" />
                <a href={`tel:${CAFE_INFO.phoneRaw}`} className="text-[#F5EFE6] underline underline-offset-4">
                  {CAFE_INFO.phone}
                </a>
              </div>
              <div className="pt-2">
                <a
                  href={`tel:${CAFE_INFO.phoneRaw}`}
                  className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#D59A67] via-[#B9683E] to-[#8C4931] text-[#F5EFE6] font-medium tracking-[0.14em] uppercase text-xs text-center block shadow-lg shadow-black/40"
                  id="mobile-drawer-call-btn"
                >
                  Call The Café
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
