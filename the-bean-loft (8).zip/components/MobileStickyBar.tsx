'use client';

import { useState, useEffect } from 'react';
import { Phone, Navigation, BookOpen } from 'lucide-react';
import { CAFE_INFO } from '@/lib/data';

export function MobileStickyBar() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show when scrolled past hero
      setIsVisible(window.scrollY > 400);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToMenu = () => {
    const el = document.getElementById('menu');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  if (!isVisible) return null;

  return (
    <div className="md:hidden fixed bottom-4 left-4 right-4 z-40">
      <div className="bg-[#1B1511]/95 backdrop-blur-md border border-[#D19A66]/40 rounded-full p-2 shadow-2xl shadow-black/80 flex items-center justify-between gap-1.5">
        <a
          href={`tel:${CAFE_INFO.phoneRaw}`}
          id="mobile-sticky-call-btn"
          className="flex-1 py-2.5 px-3 rounded-full bg-[#241B16] text-[#F5EFE6] text-[11px] font-sans-loft tracking-wider uppercase font-medium flex items-center justify-center gap-1.5 border border-[rgba(245,239,230,0.1)] active:scale-95 transition-transform"
        >
          <Phone className="w-3.5 h-3.5 text-[#D19A66]" />
          <span>Call</span>
        </a>

        <a
          href={CAFE_INFO.googleMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          id="mobile-sticky-dir-btn"
          className="flex-1 py-2.5 px-3 rounded-full bg-gradient-to-r from-[#D59A67] to-[#B9683E] text-[#F5EFE6] text-[11px] font-sans-loft tracking-wider uppercase font-medium flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-transform"
        >
          <Navigation className="w-3.5 h-3.5" />
          <span>Directions</span>
        </a>

        <button
          type="button"
          onClick={scrollToMenu}
          id="mobile-sticky-menu-btn"
          className="py-2.5 px-3 rounded-full bg-[#241B16] text-[#E7DAC8] text-[11px] font-sans-loft tracking-wider uppercase font-medium flex items-center justify-center gap-1.5 border border-[rgba(245,239,230,0.1)] active:scale-95 transition-transform"
        >
          <BookOpen className="w-3.5 h-3.5 text-[#7E8465]" />
          <span>Menu</span>
        </button>
      </div>
    </div>
  );
}
