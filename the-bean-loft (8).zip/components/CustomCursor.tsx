'use client';

import { useEffect, useState } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';

export function CustomCursor() {
  const [isVisible, setIsVisible] = useState(false);
  const [cursorType, setCursorType] = useState<'default' | 'pointer' | 'gallery' | 'button'>('default');
  const [isTouch, setIsTouch] = useState(true);

  const mouseX = useMotionValue(-100);
  const mouseY = useMotionValue(-100);

  const springConfig = { damping: 28, stiffness: 350, mass: 0.5 };
  const cursorX = useSpring(mouseX, springConfig);
  const cursorY = useSpring(mouseY, springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // If pointer is not fine (e.g., touch screen simulated or primary touch), don't show
      if (window.matchMedia('(pointer: coarse)').matches) {
        return;
      }

      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
      setIsTouch(false);
      if (!isVisible) setIsVisible(true);

      const target = e.target as HTMLElement | null;
      if (!target) return;

      const galleryEl = target.closest('[data-cursor="gallery"]');
      const ctaEl = target.closest('[data-cursor="cta"]') || target.closest('button.btn-primary');
      const interactiveEl = target.closest('a, button, input, select, textarea, [role="button"]');

      if (galleryEl) {
        setCursorType('gallery');
      } else if (ctaEl) {
        setCursorType('button');
      } else if (interactiveEl) {
        setCursorType('pointer');
      } else {
        setCursorType('default');
      }
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    document.body.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.body.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [isVisible, mouseX, mouseY]);

  if (isTouch || !isVisible) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      <motion.div
        className="fixed top-0 left-0 flex items-center justify-center rounded-full pointer-events-none -translate-x-1/2 -translate-y-1/2"
        style={{
          x: cursorX,
          y: cursorY,
        }}
      >
        {cursorType === 'gallery' ? (
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.6, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="w-16 h-16 rounded-full bg-[#E7DAC8]/95 text-[#0E0B09] flex items-center justify-center text-[10px] tracking-[0.2em] font-medium font-sans-loft shadow-lg shadow-black/40 backdrop-blur-xs"
          >
            VIEW
          </motion.div>
        ) : cursorType === 'button' ? (
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1.4 }}
            className="w-7 h-7 rounded-full border border-[#D19A66] bg-[#C47A4A]/20 backdrop-blur-xs"
          />
        ) : cursorType === 'pointer' ? (
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1.5 }}
            className="w-6 h-6 rounded-full bg-[#F5EFE6]/30 border border-[#F5EFE6]/60 backdrop-blur-xs"
          />
        ) : (
          <motion.div
            className="w-2.5 h-2.5 rounded-full bg-[#E7DAC8]/90 shadow-[0_0_8px_rgba(231,218,200,0.5)]"
          />
        )}
      </motion.div>
    </div>
  );
}
