'use client';

import { motion } from 'motion/react';
import { Star, Quote, CheckCircle2 } from 'lucide-react';
import { REVIEWS, CAFE_INFO } from '@/lib/data';

export function ReviewsSection() {
  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  return (
    <section
      id="reviews"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#0E0B09] border-t border-[rgba(245,239,230,0.08)] overflow-hidden"
      aria-label="Guest Reviews"
    >
      {/* Background ambient glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] rounded-full pointer-events-none opacity-15"
        style={{
          background: 'radial-gradient(circle, rgba(209,154,102,0.18) 0%, rgba(14,11,9,0) 70%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 sm:mb-20 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-5 h-[1.5px] bg-[#C47A4A]" />
              <span className="text-xs font-sans-loft uppercase tracking-[0.24em] text-[#D19A66] font-medium">
                GUEST IMPRESSIONS
              </span>
            </div>
            <h2 className="font-serif-loft text-3xl sm:text-5xl lg:text-6xl text-[#F5EFE6] leading-[1.08] font-light">
              Good coffee. <br />
              <span className="italic text-[#C47A4A] font-normal">Even better memories.</span>
            </h2>
          </div>

          {/* Authentic Rating Badge */}
          <div className="flex flex-col sm:items-end">
            <div className="flex items-center gap-1.5 text-[#D19A66] mb-1.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-[#D19A66]" />
              ))}
            </div>
            <div className="flex items-center gap-2 text-sm font-sans-loft">
              <span className="font-serif-loft text-2xl text-[#F5EFE6] font-normal">5.0</span>
              <span className="text-[#A99B8E]">/ 5.0 Google Rating</span>
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-[#7E8465]/20 text-[#E7DAC8] border border-[#7E8465]/30">
                100% Recommended
              </span>
            </div>
          </div>
        </div>

        {/* Spacious Editorial Quote Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {REVIEWS.map((rev, idx) => (
            <motion.div
              key={rev.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.8, delay: idx * 0.1, ease: easeLuxury }}
              className="relative p-8 sm:p-10 rounded-2xl bg-[#1B1511]/50 border border-[rgba(245,239,230,0.1)] hover:border-[#D19A66]/40 transition-colors flex flex-col justify-between"
            >
              <div>
                {/* Quote Icon and Rating Stars */}
                <div className="flex items-center justify-between mb-6">
                  <Quote className="w-8 h-8 text-[#C47A4A]/50" />
                  <div className="flex items-center gap-1 text-[#D19A66]">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#D19A66]" />
                    ))}
                  </div>
                </div>

                {/* Highlight Tag */}
                <div className="text-[11px] font-sans-loft uppercase tracking-widest text-[#D19A66] font-medium mb-3">
                  {rev.highlight}
                </div>

                {/* Main Quote Text */}
                <p className="font-serif-loft text-xl sm:text-2xl text-[#F5EFE6] font-light leading-relaxed italic mb-8">
                  &ldquo;{rev.review}&rdquo;
                </p>
              </div>

              {/* Attribution */}
              <div className="pt-6 border-t border-[rgba(245,239,230,0.08)] flex items-center justify-between">
                <div>
                  <div className="font-sans-loft font-medium text-sm text-[#F5EFE6]">
                    {rev.name}
                  </div>
                  {rev.date && (
                    <div className="text-xs font-sans-loft text-[#A99B8E] font-light">
                      {rev.date}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5 text-xs text-[#7E8465] font-sans-loft">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified Guest</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default ReviewsSection;
