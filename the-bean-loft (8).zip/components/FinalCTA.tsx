'use client';

import { motion } from 'motion/react';
import { ArrowUpRight, Coffee } from 'lucide-react';
import { CAFE_INFO } from '@/lib/data';

export function FinalCTA() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  return (
    <section
      className="relative w-full py-28 sm:py-36 lg:py-44 bg-[#0E0B09] border-t border-[rgba(245,239,230,0.08)] overflow-hidden text-center"
      aria-label="Final Invitation"
    >
      {/* Ambient warm radial glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] rounded-full pointer-events-none opacity-20"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(196,122,74,0.22) 0%, rgba(126,132,101,0.08) 40%, rgba(14,11,9,0) 75%)',
        }}
      />

      <div className="relative z-10 max-w-4xl mx-auto px-6 sm:px-8">
        {/* Subtle cup emblem */}
        <div className="flex justify-center mb-6">
          <div className="w-12 h-12 rounded-full border border-[rgba(245,239,230,0.15)] bg-[#1B1511] flex items-center justify-center text-[#D19A66]">
            <Coffee className="w-5 h-5" />
          </div>
        </div>

        {/* Small Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: easeLuxury }}
          className="text-xs font-sans-loft tracking-[0.24em] uppercase text-[#D19A66] mb-4 font-medium"
        >
          Specialty Coffee • Food • Games • Books
        </motion.div>

        {/* Subtle Reveal of "See you at The Loft." */}
        <h2 className="font-serif-loft text-5xl sm:text-7xl lg:text-8xl text-[#F5EFE6] font-light leading-[1] tracking-tight mb-8">
          <span className="block overflow-hidden pb-1">
            <motion.span
              initial={{ y: '100%' }}
              whileInView={{ y: '0%' }}
              viewport={{ once: true }}
              transition={{ duration: 0.85, delay: 0.1, ease: easeLuxury }}
              className="block"
            >
              See you at
            </motion.span>
          </span>
          <span className="block overflow-hidden pt-1">
            <motion.span
              initial={{ y: '100%' }}
              whileInView={{ y: '0%' }}
              viewport={{ once: true }}
              transition={{ duration: 0.85, delay: 0.22, ease: easeLuxury }}
              className="block italic text-[#C47A4A] font-normal"
            >
              The Loft.
            </motion.span>
          </span>
        </h2>

        <motion.p
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.35, ease: easeLuxury }}
          className="max-w-xl mx-auto font-sans-loft text-base sm:text-lg text-[#E7DAC8]/85 font-light leading-relaxed mb-10"
        >
          Whether you come to finish a chapter, celebrate a win over a board game, or savor a Spanish Latte, you’re always welcome upstairs.
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.45, ease: easeLuxury }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button
            type="button"
            onClick={() => scrollTo('visit')}
            id="final-cta-find-btn"
            data-cursor="cta"
            className="w-full sm:w-auto px-10 py-4 rounded-full text-xs font-sans-loft uppercase tracking-[0.2em] font-medium text-[#0E0B09] bg-[#F5EFE6] hover:bg-[#E7DAC8] hover:-translate-y-0.5 shadow-xl shadow-black/40 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Find The Bean Loft</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>

          <a
            href={`tel:${CAFE_INFO.phoneRaw}`}
            id="final-cta-call-btn"
            className="w-full sm:w-auto px-8 py-4 rounded-full text-xs font-sans-loft uppercase tracking-[0.18em] font-medium text-[#E7DAC8] border border-[rgba(245,239,230,0.25)] hover:border-[#D19A66] hover:text-[#F5EFE6] hover:-translate-y-0.5 transition-all duration-300"
          >
            Call {CAFE_INFO.phone}
          </a>
        </motion.div>
      </div>
    </section>
  );
}

export default FinalCTA;
