'use client';

import { ArrowUp, MapPin, Phone, Globe, Star, ArrowUpRight } from 'lucide-react';
import { CAFE_INFO } from '@/lib/data';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Our Story', href: '#story' },
    { label: 'Menu', href: '#menu' },
    { label: 'Experience', href: '#experience' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Visit', href: '#visit' },
  ];

  return (
    <footer
      className="relative w-full bg-[#0E0B09] border-t border-[rgba(245,239,230,0.1)] pt-20 sm:pt-28 overflow-hidden select-none"
      aria-label="Footer"
    >
      {/* Subtle Grain Overlay */}
      <div className="absolute inset-0 grain-overlay opacity-80 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        {/* Top Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-16 pb-16 border-b border-[rgba(245,239,230,0.08)]">
          {/* Col 1: Brand & Tagline */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-serif-loft text-3xl sm:text-4xl tracking-[0.14em] uppercase text-[#F5EFE6]">
                THE BEAN LOFT
              </span>
              <span className="w-2 h-2 rounded-full bg-[#C47A4A]" />
            </div>
            <p className="text-xs tracking-[0.24em] uppercase text-[#D19A66] font-sans-loft">
              थे बीन लॉफ्ट • SPECIALTY COFFEE & HANGOUT
            </p>
            <p className="font-sans-loft text-sm text-[#A99B8E] max-w-sm leading-relaxed font-light">
              A modern specialty coffee loft in Dombivli East. Dedicated to dialed-in extractions, slow conversations, analog games, and relaxing company.
            </p>
            <div className="pt-2 flex items-center gap-2 text-xs text-[#E7DAC8]">
              <span className="w-2 h-2 rounded-full bg-[#7E8465]" />
              <span>Open today from {CAFE_INFO.openingTime}</span>
            </div>
          </div>

          {/* Col 2: Navigation Links with subtle arrow / underline interactions */}
          <div className="lg:col-span-3">
            <div className="text-xs font-sans-loft tracking-[0.22em] uppercase text-[#D19A66] mb-5 font-medium">
              EXPLORE
            </div>
            <ul className="space-y-3 font-sans-loft text-sm">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="group inline-flex items-center gap-1.5 text-[#A99B8E] hover:text-[#F5EFE6] transition-colors"
                  >
                    <span className="relative">
                      {link.label}
                      <span className="absolute left-0 bottom-0 w-0 h-[1px] bg-[#C47A4A] group-hover:w-full transition-all duration-300" />
                    </span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-[#C47A4A] opacity-0 -translate-x-1 translate-y-1 group-hover:opacity-100 group-hover:translate-x-0 group-hover:translate-y-0 transition-all duration-300" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Contact & Visit Information */}
          <div className="lg:col-span-4 space-y-5">
            <div className="text-xs font-sans-loft tracking-[0.22em] uppercase text-[#D19A66] mb-5 font-medium">
              LOCATION & CONTACT
            </div>

            <div className="space-y-3.5 font-sans-loft text-sm text-[#A99B8E]">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#C47A4A] shrink-0 mt-1" />
                <p className="text-xs leading-relaxed text-[#E7DAC8]/90">
                  Shop 19, 1st Floor, Arya Sapphire, Chhatrapati Shivaji Maharaj Circle, opp. KDMC Ground, Dombivli East, Kalyan, Maharashtra 421203
                </p>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#D19A66] shrink-0" />
                <a
                  href={`tel:${CAFE_INFO.phoneRaw}`}
                  className="text-xs text-[#F5EFE6] hover:text-[#D19A66] transition-colors"
                >
                  {CAFE_INFO.phone}
                </a>
              </div>

              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4 text-[#7E8465] shrink-0" />
                <a
                  href={`https://${CAFE_INFO.website}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[#E7DAC8] hover:text-[#F5EFE6] transition-colors"
                >
                  {CAFE_INFO.website}
                </a>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={CAFE_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[rgba(245,239,230,0.15)] bg-[#1B1511] text-xs font-sans-loft text-[#E7DAC8] hover:border-[#D19A66] hover:text-[#F5EFE6] transition-colors"
              >
                <span>View on Google Maps</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#D19A66]" />
              </a>
            </div>
          </div>
        </div>

        {/* Oversized Brand Display Statement */}
        <div className="py-12 sm:py-16 text-center border-b border-[rgba(245,239,230,0.08)]">
          <span className="font-serif-loft text-5xl sm:text-7xl md:text-9xl text-[rgba(245,239,230,0.06)] uppercase tracking-[0.16em] block select-none">
            THE BEAN LOFT
          </span>
        </div>

        {/* Bottom Bar */}
        <div className="py-8 flex flex-col sm:flex-row items-center justify-between gap-4 font-sans-loft text-xs text-[#A99B8E]">
          <div>
            © {new Date().getFullYear()} The Bean Loft Dombivli. All rights reserved.
          </div>

          <div className="flex items-center gap-6">
            <span className="text-[11px] text-[#A99B8E]/60">
              Cormorant Garamond & Manrope
            </span>

            <button
              type="button"
              onClick={scrollToTop}
              aria-label="Back to top"
              className="flex items-center gap-1.5 text-xs text-[#E7DAC8] hover:text-[#D19A66] transition-colors cursor-pointer"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
