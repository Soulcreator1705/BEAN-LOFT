'use client';

import { useRef, useState, useEffect } from 'react';
import Image from 'next/image';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { SIGNATURE_DRINKS } from '@/lib/data';

export function FeaturedCoffee() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScrollBounds = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 10);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 10);
  };

  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    checkScrollBounds();
    el.addEventListener('scroll', checkScrollBounds, { passive: true });
    window.addEventListener('resize', checkScrollBounds);
    return () => {
      el.removeEventListener('scroll', checkScrollBounds);
      window.removeEventListener('resize', checkScrollBounds);
    };
  }, []);

  const scrollByAmount = (direction: 'left' | 'right') => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const cardWidth = el.querySelector<HTMLElement>('[data-drink-card]')?.offsetWidth || 380;
    const scrollDelta = direction === 'left' ? -cardWidth : cardWidth;
    el.scrollBy({ left: scrollDelta, behavior: 'smooth' });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowRight') {
      scrollByAmount('right');
    } else if (e.key === 'ArrowLeft') {
      scrollByAmount('left');
    }
  };

  return (
    <section
      id="featured"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#0E0B09] border-t border-[rgba(245,239,230,0.08)] overflow-hidden"
      aria-label="Featured Signature Coffee Gallery"
    >
      {/* Background ambient glow */}
      <div
        className="absolute top-1/2 left-1/3 w-[550px] h-[550px] rounded-full pointer-events-none -translate-y-1/2 opacity-20"
        style={{
          background: 'radial-gradient(circle, rgba(196,122,74,0.18) 0%, rgba(14,11,9,0) 70%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header with Navigation Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-5 h-[1.5px] bg-[#C47A4A]" />
              <span className="text-xs font-sans-loft uppercase tracking-[0.24em] text-[#D19A66] font-medium">
                CRAFT HIGHLIGHTS
              </span>
            </div>
            <h2 className="font-serif-loft text-3xl sm:text-5xl lg:text-6xl text-[#F5EFE6] leading-[1.08] font-light">
              Crafted with Intention. <br />
              <span className="italic text-[#C47A4A] font-normal">Our Signature Five.</span>
            </h2>
          </div>

          <div className="flex items-center gap-4">
            <p className="hidden md:block max-w-xs font-sans-loft text-xs text-[#A99B8E] leading-relaxed font-light">
              Micro-batch extractions, natural single-origin sweetness, and balanced finish.
            </p>

            {/* Prev / Next Gallery Buttons */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => scrollByAmount('left')}
                disabled={!canScrollLeft}
                aria-label="Previous drink"
                className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                  canScrollLeft
                    ? 'border-[rgba(245,239,230,0.25)] text-[#F5EFE6] hover:bg-[#C47A4A] hover:text-[#0E0B09] hover:border-[#C47A4A]'
                    : 'border-[rgba(245,239,230,0.08)] text-[#A99B8E]/40 cursor-not-allowed'
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => scrollByAmount('right')}
                disabled={!canScrollRight}
                aria-label="Next drink"
                className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                  canScrollRight
                    ? 'border-[rgba(245,239,230,0.25)] text-[#F5EFE6] hover:bg-[#C47A4A] hover:text-[#0E0B09] hover:border-[#C47A4A]'
                    : 'border-[rgba(245,239,230,0.08)] text-[#A99B8E]/40 cursor-not-allowed'
                }`}
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Horizontal Scroll Snap Track with Partial Card Preview */}
        <div
          ref={scrollContainerRef}
          tabIndex={0}
          onKeyDown={handleKeyDown}
          aria-label="Horizontal coffee drink carousel. Use arrow keys to navigate."
          className="flex gap-6 sm:gap-8 overflow-x-auto snap-x snap-mandatory scroll-smooth no-scrollbar pb-6 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D19A66]"
        >
          {SIGNATURE_DRINKS.map((drink, idx) => (
            <div
              key={drink.name}
              data-drink-card
              className="w-[300px] sm:w-[380px] lg:w-[420px] shrink-0 snap-start group relative rounded-2xl bg-[#1B1511] border border-[rgba(245,239,230,0.1)] hover:border-[#D19A66]/60 transition-all duration-500 overflow-hidden flex flex-col shadow-xl"
            >
              {/* Card Image Area with Overlapping Typography */}
              <div className="relative h-64 sm:h-76 w-full overflow-hidden">
                <Image
                  src={drink.image}
                  alt={drink.name}
                  fill
                  sizes="(max-width: 768px) 85vw, 420px"
                  referrerPolicy="no-referrer"
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-105 filter brightness-[0.80] contrast-[1.05]"
                />

                {/* Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1B1511] via-[#1B1511]/40 to-transparent" />

                {/* Restrained subtle watermark number */}
                <div className="absolute top-4 right-4 font-serif-loft text-5xl sm:text-6xl text-[#E7DAC8]/15 select-none pointer-events-none group-hover:text-[#D19A66]/20 transition-colors">
                  0{idx + 1}
                </div>

                {/* Price Tag Pill */}
                <div className="absolute bottom-4 left-6 px-3.5 py-1 rounded-full bg-[#0E0B09]/85 backdrop-blur-md border border-[rgba(245,239,230,0.15)] text-sm font-sans-loft text-[#E7DAC8]">
                  <span className="text-[#D19A66] font-medium mr-1">₹</span>
                  {drink.price}
                </div>

                {/* Intensity Indicator */}
                <div className="absolute bottom-4 right-6 text-[10px] tracking-widest font-sans-loft uppercase text-[#A99B8E]">
                  {drink.intensity}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[10px] tracking-[0.22em] font-sans-loft uppercase text-[#D19A66] mb-1 font-medium">
                    {drink.subtitle}
                  </div>

                  <h3 className="font-serif-loft text-2xl sm:text-3xl text-[#F5EFE6] mb-3 group-hover:text-[#D19A66] transition-colors">
                    {drink.name}
                  </h3>

                  <p className="font-sans-loft text-xs sm:text-sm text-[#A99B8E] leading-relaxed font-light mb-6">
                    {drink.description}
                  </p>
                </div>

                {/* Flavor Notes Chips */}
                <div className="pt-4 border-t border-[rgba(245,239,230,0.08)] flex flex-wrap gap-1.5">
                  {drink.notes.map((note) => (
                    <span
                      key={note}
                      className="text-[10px] tracking-wider uppercase font-sans-loft px-2.5 py-1 rounded-md bg-[#241B16] text-[#E7DAC8]/85 border border-[rgba(245,239,230,0.08)]"
                    >
                      {note}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default FeaturedCoffee;
