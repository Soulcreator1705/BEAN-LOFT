'use client';

import { useEffect, useRef } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { Star, ArrowRight } from 'lucide-react';

export function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = true;
    video.defaultMuted = true;
    video.loop = true;

    const playVideo = async () => {
      try {
        await video.play();
        console.log('Bean Loft hero video is playing');
      } catch (error) {
        console.error('Bean Loft hero autoplay failed:', error);
      }
    };

    playVideo();
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Luxury expo easing for one-time independent content reveal animation
  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  return (
    <div
      id="home"
      className="relative w-full min-h-[100svh] bg-[#0E0B09] overflow-hidden flex flex-col justify-between"
    >
      {/* 1. Background Video - Full Bleed, Behind All Content */}
      <video
        ref={videoRef}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        disablePictureInPicture
        poster="/images/bean-loft-hero-poster.jpg"
        className="
          absolute
          inset-0
          z-0
          h-full
          w-full
          object-cover
          object-[55%_center]
          pointer-events-none
        "
        aria-hidden="true"
        onLoadedData={() => {
          console.log('Bean Loft MP4 loaded');
        }}
        onCanPlay={() => {
          console.log('Bean Loft MP4 can play');
        }}
        onPlaying={() => {
          console.log('Bean Loft MP4 PLAYING');
        }}
        onError={(event) => {
          console.error('Bean Loft MP4 ERROR', event);
        }}
      >
        <source src="/bean-loft-hero.mp4" type="video/mp4" />
      </video>

      {/* 2. Gradient Overlays for Text Legibility (z-index: 10) */}
      {/* Left-to-right espresso gradient: protects text on left, preserves floating cup on center-right */}
      <div
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          background:
            'linear-gradient(90deg, rgba(14,11,9,0.88) 0%, rgba(14,11,9,0.72) 35%, rgba(14,11,9,0.28) 60%, rgba(14,11,9,0.04) 80%, rgba(14,11,9,0.18) 100%)',
        }}
      />

      {/* Mobile portrait contrast enhancement */}
      <div
        className="absolute inset-0 z-10 pointer-events-none md:hidden"
        style={{
          background:
            'linear-gradient(180deg, rgba(14,11,9,0.55) 0%, rgba(14,11,9,0.25) 30%, rgba(14,11,9,0.78) 72%, rgba(14,11,9,0.95) 100%)',
        }}
      />

      {/* Top gradient for transparent navbar clearance */}
      <div
        className="absolute top-0 left-0 right-0 z-10 h-28 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, rgba(14,11,9,0.60), transparent 100%)',
        }}
      />

      {/* Bottom transition gradient into marquee */}
      <div
        className="absolute bottom-0 left-0 right-0 z-10 h-32 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, transparent, rgba(14,11,9,0.6) 60%, #0E0B09 100%)',
        }}
      />

      {/* 3. Hero Content Layer (z-index: 20) */}
      <div className="relative z-20 flex-1 flex items-center max-w-7xl mx-auto w-full px-6 md:px-12 lg:px-16 pt-28 pb-16">
        <div className="max-w-[580px] text-left">
          {/* Eyebrow */}
          <div className="overflow-hidden mb-5 sm:mb-6">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1, ease: easeLuxury }}
              className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-[#D19A66]/30 bg-[#1B1511]/85 backdrop-blur-md shadow-xs"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#C47A4A] animate-pulse" />
              <span className="text-[11px] sm:text-xs font-sans-loft tracking-[0.22em] uppercase text-[#E7DAC8] font-medium">
                SPECIALTY COFFEE • DOMBIVLI
              </span>
              <span className="text-[#A99B8E] text-[10px] hidden sm:inline tracking-wider font-serif-loft italic">
                (थे बीन लॉफ्ट)
              </span>
            </motion.div>
          </div>

          {/* Heading with 3 Lines */}
          <h1 className="font-serif-loft text-[#F5EFE6] tracking-tight leading-[0.96] mb-6 select-none">
            <span className="block overflow-hidden pb-1">
              <motion.span
                initial={{ y: '105%' }}
                animate={{ y: '0%' }}
                transition={{ duration: 0.85, delay: 0.22, ease: easeLuxury }}
                className="block font-light text-5xl sm:text-7xl lg:text-8xl"
              >
                Coffee.
              </motion.span>
            </span>
            <span className="block overflow-hidden py-1">
              <motion.span
                initial={{ y: '105%' }}
                animate={{ y: '0%' }}
                transition={{ duration: 0.85, delay: 0.36, ease: easeLuxury }}
                className="block font-light text-5xl sm:text-7xl lg:text-8xl text-[#F5EFE6]"
              >
                Conversations.
              </motion.span>
            </span>
            <span className="block overflow-hidden pt-1">
              <motion.span
                initial={{ y: '105%' }}
                animate={{ y: '0%' }}
                transition={{ duration: 0.85, delay: 0.5, ease: easeLuxury }}
                className="block italic font-light text-5xl sm:text-7xl lg:text-8xl text-[#C47A4A]"
              >
                Good Times.
              </motion.span>
            </span>
          </h1>

          {/* Supporting Copy */}
          <div className="overflow-hidden mb-8 sm:mb-9">
            <motion.p
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.65, ease: easeLuxury }}
              className="max-w-[490px] text-sm sm:text-base md:text-[1.05rem] font-sans-loft text-[#E7DAC8]/90 font-light leading-relaxed drop-shadow-xs"
            >
              Great coffee, comforting food, games, books and the kind of atmosphere that makes you stay a little longer.
            </motion.p>
          </div>

          {/* Two CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, delay: 0.78, ease: easeLuxury }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 sm:gap-4 w-full sm:w-auto mb-8"
          >
            <button
              type="button"
              onClick={() => scrollTo('menu')}
              id="hero-explore-menu-btn"
              data-cursor="cta"
              className="group min-h-[46px] px-8 py-3.5 rounded-full text-xs font-sans-loft uppercase tracking-[0.16em] font-medium text-[#0E0B09] bg-[#F5EFE6] hover:bg-[#E7DAC8] hover:-translate-y-0.5 hover:shadow-lg hover:shadow-[#C47A4A]/20 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Explore the Menu</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#0E0B09] group-hover:translate-x-1 transition-transform duration-300" />
            </button>

            <button
              type="button"
              onClick={() => scrollTo('visit')}
              id="hero-visit-loft-btn"
              data-cursor="cta"
              className="min-h-[46px] px-8 py-3.5 rounded-full text-xs font-sans-loft uppercase tracking-[0.16em] font-medium text-[#F5EFE6] bg-transparent border border-[rgba(245,239,230,0.25)] hover:border-[#F5EFE6] hover:bg-[#F5EFE6]/08 hover:-translate-y-0.5 backdrop-blur-xs transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Visit the Loft</span>
            </button>
          </motion.div>

          {/* Rating Badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.9 }}
            className="flex items-center gap-2.5 text-xs font-sans-loft text-[#A99B8E] pt-1"
            id="hero-rating-badge"
          >
            <div className="flex items-center gap-1 text-[#D19A66]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-[#D19A66] text-[#D19A66]" />
              ))}
            </div>
            <span className="font-semibold text-[#F5EFE6] tracking-wide text-xs">5.0</span>
            <span className="text-[#A99B8E]/50">•</span>
            <span className="tracking-wide text-xs">Google Reviews (Dombivli)</span>
          </motion.div>
        </div>
      </div>

      {/* 4. Bottom Toolbar: Location hours on left & centered scroll indicator */}
      <div className="relative z-20 w-full max-w-7xl mx-auto px-6 md:px-12 lg:px-16 pb-6 flex items-center justify-between pointer-events-none">
        {/* Left location/time indicator */}
        <div className="flex items-center gap-2 text-[11px] font-sans-loft text-[#A99B8E] tracking-widest uppercase">
          <span className="w-1.5 h-1.5 rounded-full bg-[#7E8465]" />
          <span>Open from 11:30 AM Daily</span>
        </div>

        {/* Centered Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.75 }}
          transition={{ duration: 0.8, delay: 1.05 }}
          className="flex flex-col items-center gap-2 text-center select-none"
        >
          <span className="text-[10px] tracking-[0.24em] uppercase font-sans-loft text-[#E7DAC8] font-light">
            SCROLL TO EXPLORE
          </span>
          <div className="w-[1.5px] h-6 bg-[rgba(245,239,230,0.2)] relative overflow-hidden rounded-full">
            <motion.div
              animate={{ y: ['-100%', '100%'] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
              className="w-full h-1/2 bg-[#D19A66] rounded-full"
            />
          </div>
        </motion.div>

        {/* Empty right balance spacer for perfect centering */}
        <div className="w-32 hidden sm:block" />
      </div>
    </div>
  );
}

export default Hero;
