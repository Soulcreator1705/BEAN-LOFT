'use client';

import { useRef } from 'react';
import Image from 'next/image';
import { motion, useScroll, useTransform, useReducedMotion } from 'motion/react';
import { Star, Clock, MapPin } from 'lucide-react';

export function Story() {
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });

  // Subtle parallax translation of the photography inside its clipped frame
  const imageY = useTransform(scrollYProgress, [0, 1], [-25, 25]);

  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  return (
    <section
      ref={containerRef}
      id="story"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#F5EFE6] text-[#0E0B09] overflow-hidden"
      aria-label="Our Story"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
          {/* Left Column: Asymmetrical Editorial Photography with vertical mask reveal & parallax */}
          <div className="lg:col-span-6 relative">
            <motion.div
              initial={prefersReducedMotion ? { opacity: 0 } : { clipPath: 'inset(100% 0 0 0)', opacity: 0 }}
              whileInView={prefersReducedMotion ? { opacity: 1 } : { clipPath: 'inset(0% 0 0 0)', opacity: 1 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 1.1, ease: easeLuxury }}
              className="relative aspect-[4/5] sm:aspect-[5/6] w-full rounded-2xl overflow-hidden shadow-2xl shadow-stone-900/10 border border-[#E7DAC8]"
            >
              <motion.div
                className="relative w-full h-[115%] -top-[7.5%]"
                style={{ y: prefersReducedMotion ? 0 : imageY }}
              >
                <Image
                  src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1400&q=85"
                  alt="Cozy ambient loft atmosphere"
                  fill
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  referrerPolicy="no-referrer"
                  className="object-cover filter contrast-[1.02] brightness-[0.98]"
                />
              </motion.div>
            </motion.div>

            {/* Small Editorial Caption underneath */}
            <div className="mt-4 flex items-center justify-between text-xs font-sans-loft text-[#736357]">
              <span className="flex items-center gap-1.5 font-medium tracking-wider uppercase text-[#C47A4A]">
                <MapPin className="w-3.5 h-3.5 text-[#C47A4A]" />
                Arya Sapphire, 1st Floor
              </span>
              <span className="italic font-serif-loft text-sm text-[#52443B]">
                Above Chhatrapati Shivaji Maharaj Circle
              </span>
            </div>
          </div>

          {/* Right Column: Editorial Typography with staggered lines */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            {/* Small Eyebrow Label */}
            <div className="inline-flex items-center gap-2 mb-4">
              <span className="w-6 h-[1.5px] bg-[#C47A4A]" />
              <span className="text-xs font-sans-loft uppercase tracking-[0.22em] text-[#C47A4A] font-semibold">
                OUR STORY
              </span>
            </div>

            {/* Main Editorial Heading with Line-by-Line Stagger */}
            <h2 className="font-serif-loft text-4xl sm:text-5xl lg:text-6xl text-[#0E0B09] leading-[1.05] font-light mb-6">
              <span className="block overflow-hidden pb-1">
                <motion.span
                  initial={{ y: '100%' }}
                  whileInView={{ y: '0%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.1, ease: easeLuxury }}
                  className="block"
                >
                  More Than
                </motion.span>
              </span>
              <span className="block overflow-hidden pt-1">
                <motion.span
                  initial={{ y: '100%' }}
                  whileInView={{ y: '0%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.22, ease: easeLuxury }}
                  className="block italic text-[#C47A4A] font-normal"
                >
                  Just Coffee.
                </motion.span>
              </span>
            </h2>

            {/* Prompt's Core Story Statement */}
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.35, ease: easeLuxury }}
              className="font-serif-loft text-xl sm:text-2xl text-[#241B16] leading-relaxed italic font-normal mb-6"
            >
              &ldquo;The Bean Loft is a little escape above the city — a place for slow coffee, great food, conversations, games, books and moments worth staying for.&rdquo;
            </motion.p>

            {/* Easy-to-read editorial body prose */}
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.45, ease: easeLuxury }}
              className="font-sans-loft text-sm sm:text-base text-[#52443B] leading-relaxed mb-10 font-normal"
            >
              Perched on the first floor of Arya Sapphire right by Chhatrapati Shivaji Maharaj Circle, The Bean Loft was designed as an antidote to rushing. We believe the best ideas, warmest friendships, and quietest reading hours happen over thoughtfully brewed espresso, honest comfort food, and good company.
            </motion.p>

            {/* Refined Small Editorial Key Attributes */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.55, ease: easeLuxury }}
              className="grid grid-cols-2 sm:grid-cols-3 gap-6 pt-6 border-t border-[#E7DAC8]"
            >
              <div>
                <div className="flex items-center gap-1.5 text-2xl font-serif-loft text-[#0E0B09]">
                  <span className="font-semibold">5.0</span>
                  <Star className="w-4 h-4 fill-[#C47A4A] text-[#C47A4A]" />
                </div>
                <div className="text-[11px] font-sans-loft tracking-[0.16em] uppercase text-[#736357] mt-1 font-medium">
                  Guest Rating (Google)
                </div>
              </div>

              <div>
                <div className="flex items-center gap-1.5 text-2xl font-serif-loft text-[#0E0B09]">
                  <Clock className="w-5 h-5 text-[#C47A4A]" />
                  <span>11:30 AM</span>
                </div>
                <div className="text-[11px] font-sans-loft tracking-[0.16em] uppercase text-[#736357] mt-1 font-medium">
                  Doors Open Daily
                </div>
              </div>

              <div className="col-span-2 sm:col-span-1">
                <div className="text-xl font-serif-loft text-[#0E0B09] italic">
                  Coffee • Games
                </div>
                <div className="text-[11px] font-sans-loft tracking-[0.16em] uppercase text-[#736357] mt-1 font-medium">
                  Books • Good Times
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Story;
