'use client';

import { useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';

export function BrandMarquee() {
  const prefersReducedMotion = useReducedMotion();
  const [isPaused, setIsPaused] = useState(false);

  const marqueeItems = [
    'SPECIALTY COFFEE',
    'COMFORT FOOD',
    'BOARD GAMES',
    'CURATED BOOKS',
    'WARM CONVERSATIONS',
    'GOOD TIMES',
  ];

  return (
    <div
      className="relative w-full overflow-hidden border-y border-[rgba(245,239,230,0.1)] bg-[#0E0B09] py-5 sm:py-6 select-none"
      aria-label="The Bean Loft essence"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onFocus={() => setIsPaused(true)}
      onBlur={() => setIsPaused(false)}
      tabIndex={0}
    >
      {/* Edge gradient vignettes */}
      <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-[#0E0B09] to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-[#0E0B09] to-transparent z-10 pointer-events-none" />

      {prefersReducedMotion ? (
        <div className="flex flex-wrap items-center justify-center gap-6 px-4">
          {marqueeItems.map((item, idx) => (
            <div key={idx} className="flex items-center gap-4">
              <span className="font-serif-loft text-xl sm:text-2xl tracking-[0.2em] uppercase text-[#E7DAC8]">
                {item}
              </span>
              <span className="text-[#D19A66] text-xs">✦</span>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex w-max whitespace-nowrap">
          {/* Primary track */}
          <motion.div
            animate={isPaused ? { x: undefined } : { x: ['0%', '-50%'] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 42,
              ease: 'linear',
            }}
            className="flex shrink-0 items-center"
          >
            {[...Array(2)].map((_, loopIndex) => (
              <div
                key={loopIndex}
                className="flex items-center"
                aria-hidden={loopIndex > 0 ? 'true' : undefined}
              >
                {marqueeItems.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-6 sm:gap-8 px-4 sm:px-6">
                    <span
                      className="font-serif-loft text-2xl sm:text-3xl md:text-4xl tracking-[0.22em] uppercase text-transparent transition-opacity hover:opacity-100"
                      style={{
                        WebkitTextStroke: '1px rgba(245, 239, 230, 0.42)',
                      }}
                    >
                      {item}
                    </span>
                    <span className="text-[#D19A66] text-sm">✦</span>
                  </div>
                ))}
              </div>
            ))}
          </motion.div>

          {/* Secondary duplicate track for seamless infinite scroll */}
          <motion.div
            animate={isPaused ? { x: undefined } : { x: ['0%', '-50%'] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 42,
              ease: 'linear',
            }}
            className="flex shrink-0 items-center"
            aria-hidden="true"
          >
            {[...Array(2)].map((_, loopIndex) => (
              <div key={loopIndex} className="flex items-center">
                {marqueeItems.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-6 sm:gap-8 px-4 sm:px-6">
                    <span
                      className="font-serif-loft text-2xl sm:text-3xl md:text-4xl tracking-[0.22em] uppercase text-transparent transition-opacity hover:opacity-100"
                      style={{
                        WebkitTextStroke: '1px rgba(245, 239, 230, 0.42)',
                      }}
                    >
                      {item}
                    </span>
                    <span className="text-[#D19A66] text-sm">✦</span>
                  </div>
                ))}
              </div>
            ))}
          </motion.div>
        </div>
      )}
    </div>
  );
}

export default BrandMarquee;
