'use client';

import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Sparkles } from 'lucide-react';

export function AmbientSoundToggle() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseNodeRef = useRef<AudioNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  const toggleSound = () => {
    if (!isPlaying) {
      try {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioContextClass();
        audioCtxRef.current = ctx;

        // Generate warm soft low-pass filtered brownian café rumble
        const bufferSize = ctx.sampleRate * 2;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        let lastOut = 0.0;

        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          data[i] = (lastOut + 0.02 * white) / 1.02;
          lastOut = data[i];
          data[i] *= 1.8; // warm gain
        }

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        noise.loop = true;

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 420; // warm coffee shop low rumble

        const gain = ctx.createGain();
        gain.gain.value = 0.035; // gentle, non-intrusive volume

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        noise.start(0);
        noiseNodeRef.current = noise;
        gainNodeRef.current = gain;
        setIsPlaying(true);
      } catch (err) {
        console.error('Audio could not be initialized:', err);
      }
    } else {
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
        audioCtxRef.current = null;
      }
      setIsPlaying(false);
    }
  };

  useEffect(() => {
    return () => {
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
      }
    };
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-40 hidden sm:block">
      <button
        type="button"
        onClick={toggleSound}
        className="group px-3 py-2 rounded-full bg-[#1B1511]/90 backdrop-blur-md border border-[rgba(245,239,230,0.15)] hover:border-[#D19A66] text-[#E7DAC8] hover:text-[#F5EFE6] transition-all flex items-center gap-2 text-[11px] font-sans-loft shadow-lg shadow-black/40"
        title="Toggle relaxing café atmosphere sound"
      >
        {isPlaying ? (
          <>
            <div className="flex items-center gap-0.5 h-3.5">
              <span className="w-1 h-3 bg-[#D19A66] animate-pulse rounded-full" />
              <span className="w-1 h-4 bg-[#C47A4A] animate-bounce rounded-full" />
              <span className="w-1 h-2 bg-[#7E8465] animate-pulse rounded-full" />
            </div>
            <span className="text-[#D19A66] uppercase tracking-wider font-medium">Loft Ambiance On</span>
          </>
        ) : (
          <>
            <VolumeX className="w-3.5 h-3.5 text-[#A99B8E] group-hover:text-[#D19A66]" />
            <span className="text-[#A99B8E] group-hover:text-[#E7DAC8] uppercase tracking-wider">Sound: Off</span>
          </>
        )}
      </button>
    </div>
  );
}
