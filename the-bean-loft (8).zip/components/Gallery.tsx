'use client';

import { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { GALLERY_ITEMS, GalleryItem } from '@/lib/data';

export function Gallery() {
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  const openLightbox = (index: number) => {
    setSelectedImageIndex(index);
  };

  const closeLightbox = () => {
    setSelectedImageIndex(null);
  };

  const nextImage = () => {
    if (selectedImageIndex === null) return;
    setSelectedImageIndex((prev) => (prev! + 1) % GALLERY_ITEMS.length);
  };

  const prevImage = () => {
    if (selectedImageIndex === null) return;
    setSelectedImageIndex((prev) => (prev! - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length);
  };

  // Keyboard navigation for lightbox
  useEffect(() => {
    if (selectedImageIndex === null) return;

    // Focus close button on open
    setTimeout(() => {
      closeButtonRef.current?.focus();
    }, 50);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedImageIndex(null);
      } else if (e.key === 'ArrowRight') {
        setSelectedImageIndex((prev) => (prev !== null ? (prev + 1) % GALLERY_ITEMS.length : null));
      } else if (e.key === 'ArrowLeft') {
        setSelectedImageIndex((prev) => (prev !== null ? (prev - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length : null));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImageIndex]);

  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  return (
    <section
      id="gallery"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#0E0B09] overflow-hidden"
      aria-label="The Loft Gallery"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-5 h-[1.5px] bg-[#C47A4A]" />
              <span className="text-xs font-sans-loft uppercase tracking-[0.24em] text-[#D19A66] font-medium">
                VISUAL JOURNAL
              </span>
            </div>
            <h2 className="font-serif-loft text-3xl sm:text-5xl lg:text-6xl text-[#F5EFE6] leading-[1.08] font-light">
              A little glimpse <br />
              <span className="italic text-[#C47A4A] font-normal">inside The Loft.</span>
            </h2>
          </div>

          <p className="max-w-md font-sans-loft text-sm text-[#A99B8E] leading-relaxed font-light">
            Moments of craft, quiet reading nooks, board game matches, and the golden hour atmosphere over Dombivli.
          </p>
        </div>

        {/* Asymmetric Bento / Masonry Gallery Grid combining Landscape & Portrait */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-5 sm:gap-6">
          {GALLERY_ITEMS.map((item, idx) => {
            let colSpan = 'lg:col-span-4';
            let rowSpan = 'h-[320px] sm:h-[380px]';

            if (idx === 0) {
              colSpan = 'lg:col-span-8';
              rowSpan = 'h-[360px] sm:h-[440px]';
            } else if (idx === 1) {
              colSpan = 'lg:col-span-4';
              rowSpan = 'h-[360px] sm:h-[440px]';
            } else if (idx === 2) {
              colSpan = 'lg:col-span-4';
              rowSpan = 'h-[320px] sm:h-[380px]';
            } else if (idx === 3) {
              colSpan = 'lg:col-span-8';
              rowSpan = 'h-[320px] sm:h-[380px]';
            } else if (idx === 4) {
              colSpan = 'lg:col-span-6';
              rowSpan = 'h-[340px] sm:h-[400px]';
            } else if (idx === 5) {
              colSpan = 'lg:col-span-6';
              rowSpan = 'h-[340px] sm:h-[400px]';
            }

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.8, delay: (idx % 3) * 0.08, ease: easeLuxury }}
                onClick={() => openLightbox(idx)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    openLightbox(idx);
                  }
                }}
                tabIndex={0}
                role="button"
                aria-label={`View photo: ${item.title}`}
                className={`group relative rounded-2xl overflow-hidden cursor-pointer border border-[rgba(245,239,230,0.1)] hover:border-[#D19A66]/70 transition-all duration-500 shadow-xl ${colSpan} ${rowSpan} focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D19A66]`}
              >
                <Image
                  src={item.src}
                  alt={item.title}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  referrerPolicy="no-referrer"
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-105 filter brightness-[0.80] contrast-[1.05]"
                />

                {/* Ambient dark gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0E0B09]/90 via-[#0E0B09]/30 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />

                {/* Expand icon pill on hover */}
                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[#1B1511]/80 backdrop-blur-md border border-[rgba(245,239,230,0.2)] flex items-center justify-center text-[#E7DAC8] opacity-0 group-hover:opacity-100 group-hover:bg-[#C47A4A] group-hover:text-[#0E0B09] transition-all duration-300">
                  <Maximize2 className="w-4 h-4" />
                </div>

                {/* Caption and category tag */}
                <div className="absolute bottom-5 left-5 right-5 z-10">
                  <span className="text-[10px] tracking-widest font-sans-loft uppercase text-[#D19A66] font-medium block mb-1">
                    {item.category}
                  </span>
                  <h3 className="font-serif-loft text-xl sm:text-2xl text-[#F5EFE6]">
                    {item.title}
                  </h3>
                  <p className="font-sans-loft text-xs text-[#A99B8E] mt-1 font-light line-clamp-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {item.caption}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Lightbox Modal with Full Focus Management & Escape */}
      <AnimatePresence>
        {selectedImageIndex !== null && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/90 backdrop-blur-md"
            role="dialog"
            aria-modal="true"
            aria-label="Photo Lightbox"
          >
            {/* Close Button */}
            <button
              ref={closeButtonRef}
              type="button"
              onClick={closeLightbox}
              aria-label="Close lightbox"
              className="absolute top-6 right-6 z-20 w-11 h-11 rounded-full bg-[#1B1511] border border-[rgba(245,239,230,0.2)] text-[#F5EFE6] hover:bg-[#C47A4A] hover:text-[#0E0B09] flex items-center justify-center transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Navigation Arrows */}
            <button
              type="button"
              onClick={prevImage}
              aria-label="Previous photo"
              className="absolute left-4 sm:left-8 z-20 w-11 h-11 rounded-full bg-[#1B1511]/80 backdrop-blur-md border border-[rgba(245,239,230,0.2)] text-[#F5EFE6] hover:bg-[#C47A4A] hover:text-[#0E0B09] flex items-center justify-center transition-all cursor-pointer"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              type="button"
              onClick={nextImage}
              aria-label="Next photo"
              className="absolute right-4 sm:right-8 z-20 w-11 h-11 rounded-full bg-[#1B1511]/80 backdrop-blur-md border border-[rgba(245,239,230,0.2)] text-[#F5EFE6] hover:bg-[#C47A4A] hover:text-[#0E0B09] flex items-center justify-center transition-all cursor-pointer"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Image & Caption Container */}
            <motion.div
              key={selectedImageIndex}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.3 }}
              className="relative max-w-5xl w-full max-h-[85vh] flex flex-col items-center"
            >
              <div className="relative w-full h-[60vh] sm:h-[70vh] rounded-2xl overflow-hidden border border-[rgba(245,239,230,0.15)] shadow-2xl">
                <Image
                  src={GALLERY_ITEMS[selectedImageIndex].src}
                  alt={GALLERY_ITEMS[selectedImageIndex].title}
                  fill
                  sizes="100vw"
                  referrerPolicy="no-referrer"
                  className="object-contain"
                />
              </div>

              {/* Lightbox Caption */}
              <div className="mt-4 text-center max-w-xl">
                <span className="text-xs font-sans-loft uppercase tracking-widest text-[#D19A66] font-medium">
                  {GALLERY_ITEMS[selectedImageIndex].category}
                </span>
                <h3 className="font-serif-loft text-2xl text-[#F5EFE6] mt-1">
                  {GALLERY_ITEMS[selectedImageIndex].title}
                </h3>
                <p className="font-sans-loft text-xs sm:text-sm text-[#A99B8E] mt-1 font-light">
                  {GALLERY_ITEMS[selectedImageIndex].caption}
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

export default Gallery;
