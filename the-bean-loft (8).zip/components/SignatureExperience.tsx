'use client';

import Image from 'next/image';
import { motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { EXPERIENCE_TILES } from '@/lib/data';

export function SignatureExperience() {
  const prefersReducedMotion = useReducedMotion();
  const easeLuxury = [0.16, 1, 0.3, 1] as const;

  const scrollToMenu = () => {
    const el = document.getElementById('menu');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="experience"
      className="relative w-full py-24 sm:py-32 lg:py-40 bg-[#0E0B09] border-t border-[rgba(245,239,230,0.08)]"
      aria-label="The Four Pillars of The Loft"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="max-w-3xl mb-14 sm:mb-20">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-5 h-[1.5px] bg-[#C47A4A]" />
            <span className="text-xs font-sans-loft uppercase tracking-[0.24em] text-[#D19A66] font-medium">
              SIGNATURE EXPERIENCES
            </span>
          </div>

          <h2 className="font-serif-loft text-3xl sm:text-5xl lg:text-6xl text-[#F5EFE6] leading-[1.08] font-light">
            There’s always a reason <br />
            <span className="italic text-[#C47A4A] font-normal">to stay a little longer.</span>
          </h2>
        </div>

        {/* 4 Interactive Editorial Tiles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {EXPERIENCE_TILES.map((tile, idx) => (
            <motion.div
              key={tile.id}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{
                duration: 0.75,
                delay: prefersReducedMotion ? 0 : idx * 0.08,
                ease: easeLuxury,
              }}
              onClick={scrollToMenu}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  scrollToMenu();
                }
              }}
              tabIndex={0}
              role="button"
              aria-label={`Explore ${tile.title}: ${tile.subtitle}`}
              className="group relative h-[440px] sm:h-[490px] rounded-2xl overflow-hidden cursor-pointer border border-[rgba(245,239,230,0.12)] hover:border-[#D19A66]/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D19A66] transition-all duration-500 shadow-xl shadow-black/40 flex flex-col justify-between p-6 sm:p-7"
              id={`experience-tile-${tile.id}`}
            >
              {/* Tile Background Image with gentle hover zoom */}
              <div className="absolute inset-0 overflow-hidden -z-10">
                <Image
                  src={tile.image}
                  alt={tile.title}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                  referrerPolicy="no-referrer"
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04] filter brightness-[0.72] contrast-[1.06]"
                />
              </div>

              {/* Darkening Linear Gradient Overlay */}
              <div className="absolute inset-0 -z-10 bg-gradient-to-t from-[#0E0B09] via-[#0E0B09]/55 to-[#0E0B09]/20 group-hover:via-[#0E0B09]/45 transition-colors duration-500" />

              {/* Top Meta: Oversized subtle numbering & small arrow reveal */}
              <div className="relative z-10 flex items-center justify-between w-full">
                <span className="font-serif-loft text-3xl sm:text-4xl text-[#E7DAC8]/40 tracking-wider group-hover:text-[#F5EFE6] transition-colors">
                  {tile.number}
                </span>

                <div className="w-9 h-9 rounded-full bg-[#1B1511]/80 backdrop-blur-xs border border-[rgba(245,239,230,0.2)] flex items-center justify-center text-[#E7DAC8] opacity-70 group-hover:opacity-100 group-hover:bg-[#C47A4A] group-hover:text-[#0E0B09] group-hover:border-[#C47A4A] transition-all duration-300">
                  <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </div>

              {/* Bottom Content: Subtitle, Title & Description */}
              <div className="relative z-10 flex flex-col justify-end transform transition-transform duration-500 group-hover:-translate-y-1">
                <div className="text-[10px] tracking-[0.24em] font-sans-loft text-[#D19A66] uppercase mb-1.5 font-medium">
                  {tile.subtitle}
                </div>

                <h3 className="font-serif-loft text-2xl sm:text-3xl text-[#F5EFE6] tracking-wide uppercase mb-3">
                  {tile.title}
                </h3>

                <p className="font-sans-loft text-xs sm:text-sm text-[#E7DAC8]/85 line-clamp-3 leading-relaxed font-light mb-4">
                  {tile.description}
                </p>

                {/* Subtle tags */}
                <div className="flex flex-wrap gap-1.5 pt-3 border-t border-[rgba(245,239,230,0.1)]">
                  {tile.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] tracking-wider uppercase font-sans-loft text-[#A99B8E] bg-[#0E0B09]/70 px-2 py-0.5 rounded border border-[rgba(245,239,230,0.08)]"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default SignatureExperience;
