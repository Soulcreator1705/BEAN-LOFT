import { CustomCursor } from '@/components/CustomCursor';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { BrandMarquee } from '@/components/BrandMarquee';
import { Story } from '@/components/Story';
import { SignatureExperience } from '@/components/SignatureExperience';
import { MenuSection } from '@/components/MenuSection';
import { FeaturedCoffee } from '@/components/FeaturedCoffee';
import { LoftExperience } from '@/components/LoftExperience';
import { Gallery } from '@/components/Gallery';
import { ReviewsSection } from '@/components/ReviewsSection';
import { VisitSection } from '@/components/VisitSection';
import { FinalCTA } from '@/components/FinalCTA';
import { Footer } from '@/components/Footer';
import { MobileStickyBar } from '@/components/MobileStickyBar';
import { AmbientSoundToggle } from '@/components/AmbientSoundToggle';

export default function Home() {
  return (
    <main className="relative min-h-screen bg-[#0E0B09] text-[#F7F0E8] overflow-x-clip selection:bg-[#C47A4A] selection:text-[#0E0B09]">
      {/* Desktop Tasteful Custom Cursor */}
      <CustomCursor />

      {/* Floating Sticky Navigation */}
      <Navbar />

      {/* Main Content Sections */}
      <Hero />
      <BrandMarquee />
      <Story />
      <SignatureExperience />
      <MenuSection />
      <FeaturedCoffee />
      <LoftExperience />
      <Gallery />
      <ReviewsSection />
      <VisitSection />
      <FinalCTA />

      {/* Footer */}
      <Footer />

      {/* Mobile Sticky Quick Navigation */}
      <MobileStickyBar />

      {/* Subtle Ambient Sound Mode */}
      <AmbientSoundToggle />
    </main>
  );
}
