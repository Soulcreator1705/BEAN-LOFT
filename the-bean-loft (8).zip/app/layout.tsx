import type {Metadata} from 'next';
import { Cormorant_Garamond, Manrope } from 'next/font/google';
import './globals.css';

const cormorantGaramond = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-cormorant',
  display: 'swap',
});

const manrope = Manrope({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-manrope',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'The Bean Loft | Specialty Coffee, Food, Games & Books in Dombivli',
  description: 'The Bean Loft (थे बीन लॉफ्ट) — Premium specialty coffee, comforting food, board games, books & memorable conversations in Dombivli East, Maharashtra.',
  openGraph: {
    title: 'The Bean Loft | Specialty Coffee, Food, Games & Books in Dombivli',
    description: 'The Bean Loft (थे बीन लॉफ्ट) — Premium specialty coffee, comforting food, board games, books & memorable conversations in Dombivli East, Maharashtra.',
    type: 'website',
    url: 'https://thebeanloft.com',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The Bean Loft | Specialty Coffee, Food, Games & Books in Dombivli',
    description: 'The Bean Loft (थे बीन लॉफ्ट) — Premium specialty coffee, comforting food, board games, books & memorable conversations in Dombivli East, Maharashtra.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${cormorantGaramond.variable} ${manrope.variable} scroll-smooth`}>
      <body className="bg-[#0E0B09] text-[#F7F0E8] font-sans-loft antialiased selection:bg-[#C47A4A] selection:text-[#0E0B09]">
        {children}
      </body>
    </html>
  );
}

